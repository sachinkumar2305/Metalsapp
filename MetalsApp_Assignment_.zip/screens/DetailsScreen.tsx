import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { useRoute } from "@react-navigation/native";

export default function DetailsScreen() {
  const route = useRoute<any>();
  const { metalData } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{metalData.name} Details</Text>
      <Text style={styles.info}>Current Price: ₹ {metalData.price}</Text>
      <Text style={styles.info}>Previous Close: ₹ {metalData.prevClose}</Text>
      <Text style={styles.info}>Previous Open: ₹ {metalData.prevOpen}</Text>
      <Text style={styles.info}>Date: {metalData.date}</Text>
      <Text style={styles.info}>Time: {metalData.time}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#111", justifyContent: "center", alignItems: "center" },
  title: { fontSize: 22, fontWeight: "bold", color: "gold", marginBottom: 20 },
  info: { fontSize: 18, color: "white", marginVertical: 5 }
});
