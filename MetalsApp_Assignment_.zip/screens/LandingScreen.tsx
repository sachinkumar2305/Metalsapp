import React, { useEffect, useState } from "react";
import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet } from "react-native";
import { useNavigation } from "@react-navigation/native";

const mockAPI = {
  gold: { name: "Gold", price: 6000, prevClose: 5950, prevOpen: 5900, date: "2025-08-29", time: "10:00 AM" },
  silver: { name: "Silver", price: 75, prevClose: 74, prevOpen: 73, date: "2025-08-29", time: "10:00 AM" },
  palladium: { name: "Palladium", price: 1200, prevClose: 1185, prevOpen: 1190, date: "2025-08-29", time: "10:00 AM" }
};

export default function LandingScreen() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);
  const navigation = useNavigation();

  useEffect(() => {
    setTimeout(() => {
      setData(mockAPI);
      setLoading(false);
    }, 1500);
  }, []);

  if (loading) {
    return <View style={styles.loader}><ActivityIndicator size="large" color="gold" /></View>;
  }

  return (
    <View style={styles.container}>
      {Object.values(data).map((item: any, idx: number) => (
        <TouchableOpacity key={idx} style={styles.tile} onPress={() => navigation.navigate("Details", { metalData: item })}>
          <Text style={styles.name}>{item.name}</Text>
          <Text style={styles.price}>₹ {item.price}</Text>
          <Text style={styles.time}>{item.time}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#111", padding: 20 },
  tile: { backgroundColor: "#222", padding: 20, borderRadius: 12, marginVertical: 10 },
  name: { color: "gold", fontSize: 20, fontWeight: "bold" },
  price: { color: "white", fontSize: 18 },
  time: { color: "gray", fontSize: 14 }
});
