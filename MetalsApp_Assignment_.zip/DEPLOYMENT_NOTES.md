# Metals Price App - Internship Assignment

## Author
- Name: Sachin Kumar
- Email: sk4327419@gmail.com

## Description
A React Native Expo app that displays live metal prices (Gold, Silver, Palladium) using a mock API.
Users can see the landing page with tiles for each metal. Clicking a tile navigates to the details page
with information such as previous close, previous open, today’s price, date, and time.

## Deployment Notes
- Install dependencies: `npm install` or `yarn install`
- Start the app: `expo start`
- Run on Android: press `a`
- Run on iOS (Mac only): press `i`
- Run on web: press `w`

## How to Execute
1. Clone or unzip the project.
2. Run `npm install` to install dependencies.
3. Use `expo start` to start Metro bundler.
4. Scan QR code in Expo Go app or run in emulator.

## Approach
- Used React Native with Expo for easy cross-platform development.
- Created mock API file to simulate fetching metal prices.
- Designed Landing Page with tiles for Gold, Silver, Palladium showing price + time.
- Added navigation to Details Screen for full info about the selected metal.
- Implemented error handling and loading states for each fetch.

## Challenges & Unresolved Notes
- Could not integrate real API (goldapi.io) due to free tier restrictions, so mock data used.
- UI simplified to meet assignment requirements; further styling can be added for trading-view-like charts.
- Tested on Expo Go; native builds (APK/IPA) not included.
