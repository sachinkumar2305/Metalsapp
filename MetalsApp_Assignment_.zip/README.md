# Metals Price App

📱 **React Native Expo app** that shows live prices of **Gold, Silver, Palladium** (using a mock API).  
Clicking on any metal opens a detailed page with previous close, open, date & time.

---

## 🚀 How to Run
1. Install Expo CLI if not already: `npm install -g expo-cli`
2. Install dependencies: `npm install`
3. Run the app: `expo start`
4. Open on Android/iOS simulator or Expo Go.

---

## 📊 Features
- Landing page with metal price tiles
- Detail page with extra information
- Mock API for demonstration
- Loading states & error handling

---

## 🧑 Author
**Sachin Kumar**  
📧 sk4327419@gmail.com

---

## 🛠 Challenges / Notes
- Mock API used instead of real goldapi.io due to assignment restrictions.
- Can be extended with live APIs easily.

